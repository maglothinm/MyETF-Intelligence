#!/usr/bin/env python3
"""Compatibility entry point that adds the Investor Edge heat map to MyETF Pages."""
from __future__ import annotations

import sys
from typing import Sequence

try:
    from . import build_trade_dashboard_core as _core
    from .investor_edge import build_dashboard_addon
except ImportError:  # direct script execution
    import build_trade_dashboard_core as _core  # type: ignore
    from investor_edge import build_dashboard_addon  # type: ignore

_ORIGINAL_MAIN = _core.main


def _main(argv: Sequence[str] | None = None) -> int:
    args = _core.build_parser().parse_args(argv)
    result = _ORIGINAL_MAIN(argv)
    if result == 0:
        build_dashboard_addon(args.ai_dir, args.output_dir)
        print(f"Investor Edge dashboard built at {args.output_dir / 'investor-edge.html'}")
    return result


_core.main = _main
_core.build_dashboard_addon = build_dashboard_addon

if __name__ == "__main__":
    raise SystemExit(_main())

sys.modules[__name__] = _core
