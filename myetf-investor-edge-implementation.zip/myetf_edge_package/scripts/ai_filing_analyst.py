#!/usr/bin/env python3
"""Compatibility entry point adding Investor Edge to the existing AI analyst."""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

try:
    from . import ai_filing_analyst_core as _core
    from .investor_edge import EDGE_VERSION, InvestorEdgeRuntime, apply_profile_to_analysis
except ImportError:  # direct script execution
    import ai_filing_analyst_core as _core  # type: ignore
    from investor_edge import EDGE_VERSION, InvestorEdgeRuntime, apply_profile_to_analysis  # type: ignore

LOGGER = logging.getLogger("myetf-investor-edge")
_ORIGINAL_RUN_ANALYST = _core.run_analyst
_ORIGINAL_BUILD_ANALYSIS_RECORD = _core.build_analysis_record
_ORIGINAL_REFRESH_ANALYSIS_MARKET = _core.refresh_analysis_market
_ORIGINAL_NOTIFY_CANDIDATE = _core.notify_candidate
_ACTIVE_RUNTIME: InvestorEdgeRuntime | None = None
_ACTIVE_TRANSACTIONS: Sequence[Mapping[str, Any]] = ()
_ACTIVE_RULES: Mapping[str, Any] = {}


def _edge_config_path(config: Any) -> Path:
    explicit = os.environ.get("INVESTOR_EDGE_CONFIG", "").strip()
    if explicit:
        return Path(explicit)
    return Path(config.rules_path).with_name("investor_edge.yml")


def _edge_build_analysis_record(*args: Any, **kwargs: Any) -> dict[str, Any]:
    record = _ORIGINAL_BUILD_ANALYSIS_RECORD(*args, **kwargs)
    runtime = _ACTIVE_RUNTIME
    if runtime is None or not runtime.enabled:
        return record
    trade = kwargs.get("trade") or (args[0] if args else {})
    all_transactions = kwargs.get("all_transactions") or _ACTIVE_TRANSACTIONS
    rules = kwargs.get("rules") or _ACTIVE_RULES
    profile = runtime.profile_for_trade(trade, all_transactions)
    updated = apply_profile_to_analysis(record, profile, rules)
    updated["entry_plan"] = _core.build_entry_plan(
        trade, updated.get("market") or {}, int(updated.get("score") or 0), rules
    )
    return updated


def _edge_refresh_analysis_market(*args: Any, **kwargs: Any) -> dict[str, Any]:
    refreshed = _ORIGINAL_REFRESH_ANALYSIS_MARKET(*args, **kwargs)
    runtime = _ACTIVE_RUNTIME
    if runtime is None or not runtime.enabled:
        return refreshed
    analysis = args[0] if args else kwargs.get("analysis", {})
    trade = args[1] if len(args) > 1 else kwargs.get("trade", {})
    all_transactions = args[2] if len(args) > 2 else kwargs.get("all_transactions", _ACTIVE_TRANSACTIONS)
    rules = args[4] if len(args) > 4 else kwargs.get("rules", _ACTIVE_RULES)
    # The core refresh recomputes the deterministic base score. Remove stale edge metadata
    # carried over from the prior record before applying the fresh modifier.
    for field in (
        "base_score", "base_raw_score", "investor_edge", "investor_edge_modifier", "score_method_version"
    ):
        refreshed.pop(field, None)
    components = dict(refreshed.get("score_components") or {})
    components.pop("investor_edge_modifier", None)
    refreshed["score_components"] = components
    profile = runtime.profile_for_trade(trade, all_transactions)
    updated = apply_profile_to_analysis(refreshed, profile, rules)
    updated["entry_plan"] = _core.build_entry_plan(
        trade, updated.get("market") or {}, int(updated.get("score") or 0), rules
    )
    return updated


def _edge_notify_candidate(config: Any, analysis: Mapping[str, Any]) -> None:
    edge = analysis.get("investor_edge") or {}
    if not isinstance(edge, Mapping) or not edge:
        return _ORIGINAL_NOTIFY_CANDIDATE(config, analysis)
    enriched = dict(analysis)
    ai = dict(enriched.get("ai") or {})
    prefix = (
        f"Investor Edge {float(edge.get('edge_score') or 50):.0f}/100 "
        f"({int(edge.get('modifier') or 0):+d} score, {int(edge.get('sample_count') or 0)} prior scored trades; "
        f"{edge.get('confidence_label', 'Low')} confidence). "
    )
    ai["analysis_summary"] = prefix + str(ai.get("analysis_summary") or "")
    enriched["ai"] = ai
    return _ORIGINAL_NOTIFY_CANDIDATE(config, enriched)


def _latest_by(rows: Sequence[Mapping[str, Any]], key: str) -> dict[str, dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for row in rows:
        value = str(row.get(key) or "")
        if value:
            latest[value] = dict(row)
    return latest


def _backfill_existing(config: Any, runtime: InvestorEdgeRuntime) -> None:
    analyses_path = Path(config.ai_dir) / "analyses.jsonl"
    analyses = _core.read_jsonl(analyses_path)
    if not analyses:
        return
    latest = _latest_by(analyses, "trade_id")
    transactions, _ = _core.merge_tracker_data(config)
    by_id = {str(item.get("trade_id") or ""): item for item in transactions}
    rules = _core.load_rules(config.rules_path)
    candidates = [
        item for item in latest.values()
        if str(item.get("score_method_version") or "") != EDGE_VERSION
    ]
    candidates.sort(key=lambda item: str(item.get("analyzed_at_utc") or ""), reverse=True)
    limit = int(runtime.config.get("backfill_analysis_limit_per_run", 30))
    updated_rows: list[dict[str, Any]] = []
    for analysis in candidates[: max(0, limit)]:
        trade = by_id.get(str(analysis.get("trade_id") or ""))
        if not trade:
            continue
        clean = dict(analysis)
        # Initial rollout records predate Investor Edge. If a future Edge version backfills
        # a previously Edge-scored record, restore its persisted base before applying the
        # new methodology so modifiers never compound.
        if analysis.get("base_score") is not None:
            clean["score"] = int(analysis.get("base_score") or 0)
        if analysis.get("base_raw_score") is not None:
            clean["raw_score"] = int(analysis.get("base_raw_score") or clean.get("score") or 0)
        components = dict(clean.get("score_components") or {})
        components.pop("investor_edge_modifier", None)
        clean["score_components"] = components
        for field in ("base_score", "base_raw_score", "investor_edge", "investor_edge_modifier", "score_method_version"):
            clean.pop(field, None)
        profile = runtime.profile_for_trade(trade, transactions)
        rescored = apply_profile_to_analysis(clean, profile, rules)
        rescored["entry_plan"] = _core.build_entry_plan(
            trade, rescored.get("market") or {}, int(rescored.get("score") or 0), rules
        )
        rescored["investor_edge_backfilled_utc"] = _core.iso_utc()
        updated_rows.append(rescored)
    if updated_rows:
        _core.append_jsonl(analyses_path, updated_rows)
        state, _ = _core.load_state(Path(config.ai_dir) / "state.json")
        _core.write_latest_outputs(config, _core.read_jsonl(analyses_path), state)


def _edge_run_analyst(config: Any, *, session: Any = None, client_factory: Any = None) -> Any:
    global _ACTIVE_RUNTIME, _ACTIVE_TRANSACTIONS, _ACTIVE_RULES
    runtime_session = session or _core.build_session(config.repository_url or "MyETF Investor Edge")
    runtime = InvestorEdgeRuntime.create(
        ai_dir=Path(config.ai_dir),
        session=runtime_session,
        alphavantage_api_key=config.alphavantage_api_key,
        finnhub_api_key=config.finnhub_api_key,
        alphavantage_entitlement=config.alphavantage_entitlement,
        request_timeout=config.request_timeout,
        config_path=_edge_config_path(config),
    )
    _ACTIVE_RUNTIME = runtime
    _ACTIVE_TRANSACTIONS, _ = _core.merge_tracker_data(config)
    _ACTIVE_RULES = _core.load_rules(config.rules_path)
    try:
        result = _ORIGINAL_RUN_ANALYST(
            config,
            session=runtime_session,
            client_factory=client_factory,
        )
        if runtime.enabled and config.enabled:
            try:
                _backfill_existing(config, runtime)
                transactions, _ = _core.merge_tracker_data(config)
                leaderboard = runtime.refresh_leaderboard(transactions)
                runtime.save(leaderboard)
            except Exception as exc:  # noqa: BLE001
                LOGGER.exception("Investor Edge backfill/leaderboard failed")
                result.warnings.append(f"Investor Edge backfill: {type(exc).__name__}: {exc}")
                runtime.save()
        return result
    finally:
        _ACTIVE_RUNTIME = None
        _ACTIVE_TRANSACTIONS = ()
        _ACTIVE_RULES = {}


# Patch the preserved core module. Imports of scripts.ai_filing_analyst are then aliased to
# that module so pytest monkeypatching and existing callers continue to affect core globals.
_core.build_analysis_record = _edge_build_analysis_record
_core.refresh_analysis_market = _edge_refresh_analysis_market
_core.notify_candidate = _edge_notify_candidate
_core.run_analyst = _edge_run_analyst
_core.INVESTOR_EDGE_VERSION = EDGE_VERSION


def _main(argv: Sequence[str] | None = None) -> int:
    parser = _core.build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    config = _core.build_config(args)
    result = _edge_run_analyst(config)
    if result.success:
        LOGGER.info(
            "AI analyst + Investor Edge completed: eligible=%s analyzed=%s high=%s watch=%s opened=%s",
            result.eligible_transaction_count,
            result.completed_count,
            result.high_priority_count,
            result.watchlist_count,
            result.paper_positions_opened,
        )
        return 0
    LOGGER.error("AI analyst failed: %s", "; ".join(result.errors))
    return 1


if __name__ == "__main__":
    raise SystemExit(_main())

sys.modules[__name__] = _core
