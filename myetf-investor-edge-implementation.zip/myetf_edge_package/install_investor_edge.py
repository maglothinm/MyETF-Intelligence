#!/usr/bin/env python3
"""Install the prepared MyETF Investor Edge implementation into a repo checkout.

Usage:
    python install_investor_edge.py /path/to/MyETF

The installer preserves the current analyst/dashboard implementations as *_core.py,
then puts compatibility wrappers at the original paths. It refuses to overwrite a
pre-existing core file unless it is byte-identical to the current source.
"""
from __future__ import annotations

import hashlib
import shutil
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def preserve_core(target: Path, source_name: str, core_name: str) -> None:
    source = target / "scripts" / source_name
    core = target / "scripts" / core_name
    if not source.exists():
        raise SystemExit(f"Missing expected MyETF source file: {source}")
    if core.exists():
        if digest(core) != digest(source):
            # An already-installed wrapper makes source differ from core; that is valid.
            if "Compatibility entry point" in source.read_text(encoding="utf-8", errors="ignore"):
                return
            raise SystemExit(
                f"Refusing to overwrite existing {core}. Review it before reinstalling."
            )
        return
    shutil.copy2(source, core)


def copy_file(target: Path, relative: str) -> None:
    src = PACKAGE_ROOT / relative
    dst = target / relative
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f"installed {relative}")


def main() -> int:
    target = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    if not (target / ".github").exists() or not (target / "scripts").exists():
        raise SystemExit(f"{target} does not look like the MyETF repository root")

    preserve_core(target, "ai_filing_analyst.py", "ai_filing_analyst_core.py")
    preserve_core(target, "build_trade_dashboard.py", "build_trade_dashboard_core.py")

    for relative in (
        "scripts/investor_edge.py",
        "scripts/ai_filing_analyst.py",
        "scripts/build_trade_dashboard.py",
        "config/investor_edge.yml",
        "tests/test_investor_edge.py",
        ".github/workflows/investor_edge_tests.yml",
        "README_INVESTOR_EDGE.md",
    ):
        copy_file(target, relative)

    print("\nInvestor Edge installed. Recommended validation:")
    print("python -m pytest -q tests/test_investor_edge.py tests/test_ai_filing_analyst.py tests/test_trade_dashboard.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
