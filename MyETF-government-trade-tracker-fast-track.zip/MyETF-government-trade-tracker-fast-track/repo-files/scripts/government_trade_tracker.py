#!/usr/bin/env python3
"""Track newly disclosed government purchases from official House, Senate, and OGE sources.

The tracker is intentionally fail-closed for electronic sources: a source schema change,
missing durable state, unreadable electronic report, or failed required notification exits
non-zero. Known paper filings are retained as manual-review records instead of being
silently discarded.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import os
import re
import tempfile
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from requests import Response, Session

try:  # Support both ``python -m scripts...`` and direct script execution.
    from .monitor_disclosures import (
        DEFAULT_MAX_DOWNLOAD_BYTES,
        DEFAULT_MAX_OCR_PAGES,
        DEFAULT_TIMEOUT,
        PUSHOVER_MESSAGES_URL,
        MonitorError,
        Report,
        SourceChangedError,
        _senate_page_response,
        build_session,
        checked_response,
        extract_pdf_text,
        fetch_house_reports,
        fetch_pdf_bytes,
        fetch_senate_reports,
        normalize_text,
        parse_bool,
        response_bytes,
        utc_now,
    )
except ImportError:  # pragma: no cover - direct execution path
    from monitor_disclosures import (  # type: ignore
        DEFAULT_MAX_DOWNLOAD_BYTES,
        DEFAULT_MAX_OCR_PAGES,
        DEFAULT_TIMEOUT,
        PUSHOVER_MESSAGES_URL,
        MonitorError,
        Report,
        SourceChangedError,
        _senate_page_response,
        build_session,
        checked_response,
        extract_pdf_text,
        fetch_house_reports,
        fetch_pdf_bytes,
        fetch_senate_reports,
        normalize_text,
        parse_bool,
        response_bytes,
        utc_now,
    )

LOGGER = logging.getLogger("government-trade-tracker")

STATE_VERSION = 1
DEFAULT_LEGISLATIVE_STATE = Path(".trade-tracker/legislative/state.json")
DEFAULT_EXECUTIVE_STATE = Path(".trade-tracker/executive/state.json")
DEFAULT_LEGISLATIVE_LEDGER = Path(".trade-tracker/legislative/purchases.jsonl")
DEFAULT_EXECUTIVE_LEDGER = Path(".trade-tracker/executive/purchases.jsonl")
DEFAULT_LEGISLATIVE_PENDING = Path(".trade-tracker/legislative/pending-review.jsonl")
DEFAULT_EXECUTIVE_PENDING = Path(".trade-tracker/executive/pending-review.jsonl")
DEFAULT_LEGISLATIVE_RESULT = Path("legislative-result.json")
DEFAULT_EXECUTIVE_RESULT = Path("executive-result.json")
DEFAULT_LEGISLATIVE_CSV = Path("legislative-latest-purchases.csv")
DEFAULT_EXECUTIVE_CSV = Path("executive-latest-purchases.csv")
DEFAULT_SENATE_LOOKBACK_DAYS = 180
DEFAULT_MAX_SEEN_FILINGS = 50_000
DEFAULT_MAX_SEEN_TRADES = 250_000
DEFAULT_LATEST_CSV_ROWS = 1_000

OWNER_LABELS = {
    "": "Self",
    "SELF": "Self",
    "SP": "Spouse",
    "SPOUSE": "Spouse",
    "JT": "Joint",
    "JOINT": "Joint",
    "DC": "Dependent Child",
    "DEPENDENT CHILD": "Dependent Child",
    "CHILD": "Dependent Child",
}

TRANSACTION_LABELS = {
    "P": "Purchase",
    "PURCHASE": "Purchase",
    "BUY": "Purchase",
    "S": "Sale",
    "SALE": "Sale",
    "SALE (FULL)": "Sale (Full)",
    "SALE (PARTIAL)": "Sale (Partial)",
    "E": "Exchange",
    "EXCHANGE": "Exchange",
}

HOUSE_TRANSACTION_RE = re.compile(
    r"(?<![A-Z0-9])(?P<type>P|S|E)\s+"
    r"(?P<date>\d{1,2}/\d{1,2}/\d{2,4})\s+"
    r"(?P<notification>\d{1,2}/\d{1,2}/\d{2,4})\s+"
    r"(?P<amount>(?:Over\s+)?\$[\d,]+(?:\.\d{2})?(?:\s*[-–—]\s*\$?[\d,]+(?:\.\d{2})?)?)",
    re.IGNORECASE,
)

GENERIC_TRANSACTION_RE = re.compile(
    r"(?P<type>Purchase|Sale(?:\s*\((?:Full|Partial)\))?|Exchange)\s+"
    r"(?P<date>\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{1,2}-\d{1,2})\s+"
    r"(?:(?P<notice>Yes|No)\s+)?"
    r"(?P<amount>(?:Over\s+)?\$[\d,]+(?:\.\d{2})?(?:\s*[-–—]\s*\$?[\d,]+(?:\.\d{2})?)?)",
    re.IGNORECASE,
)

DATE_RE = re.compile(r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{1,2}-\d{1,2})\b")
AMOUNT_RE = re.compile(
    r"(?:Over\s+)?\$[\d,]+(?:\.\d{2})?(?:\s*[-–—]\s*\$?[\d,]+(?:\.\d{2})?)?",
    re.IGNORECASE,
)
TICKER_RE = re.compile(r"\(([A-Z][A-Z0-9.\-]{0,7})\)")
ASSET_CODE_RE = re.compile(r"\[([A-Z0-9]{2,5})\]\s*$", re.IGNORECASE)

EQUITY_CODES = {"ST", "OP", "SO", "RS", "RSU", "EF", "ETF"}
EQUITY_TYPE_TERMS = (
    "stock",
    "common equity",
    "preferred equity",
    "stock option",
    "exchange traded fund",
    "exchange-traded fund",
    "etf",
)
NON_EQUITY_TERMS = (
    "bond",
    "note",
    "treasury",
    "municipal",
    "certificate of deposit",
    "money market",
    "mutual fund",
    "index fund",
    "real estate",
    "limited partnership",
    "private equity fund",
    "venture fund",
)


class NotificationError(MonitorError):
    """Raised when a required purchase or review notification cannot be delivered."""


class PaperFilingError(MonitorError):
    """Raised for a known paper filing that requires a human review."""


@dataclass(frozen=True)
class Trade:
    trade_id: str
    observed_at_utc: str
    branch: str
    source: str
    report_id: str
    filer: str
    chamber: str
    title: str
    agency: str
    owner: str
    asset: str
    ticker: str
    asset_type: str
    transaction_type: str
    transaction_date: str
    notification_date: str
    filed_date: str
    amount: str
    source_url: str
    raw_row: str
    equity_like: bool
    parse_confidence: str


@dataclass(frozen=True)
class PendingReview:
    review_id: str
    observed_at_utc: str
    branch: str
    source: str
    report_id: str
    filer: str
    filed_date: str
    source_url: str
    reason: str
    title: str = ""
    agency: str = ""


@dataclass
class TrackerState:
    version: int = STATE_VERSION
    seen_filings: dict[str, dict[str, str]] = field(
        default_factory=lambda: {"house": {}, "senate": {}, "oge": {}}
    )
    seen_trades: dict[str, str] = field(default_factory=dict)
    seen_reviews: dict[str, str] = field(default_factory=dict)
    last_attempt_utc: str | None = None
    last_success_utc: str | None = None
    last_counts: dict[str, int] = field(default_factory=dict)

    def is_filing_seen(self, source: str, filing_id: str) -> bool:
        return filing_id in self.seen_filings.setdefault(source, {})

    def mark_filing_seen(self, source: str, filing_id: str, timestamp: str) -> None:
        self.seen_filings.setdefault(source, {})[filing_id] = timestamp

    def prune(self) -> None:
        for source, records in self.seen_filings.items():
            if len(records) > DEFAULT_MAX_SEEN_FILINGS:
                ordered = sorted(records.items(), key=lambda item: item[1], reverse=True)
                self.seen_filings[source] = dict(ordered[:DEFAULT_MAX_SEEN_FILINGS])
        if len(self.seen_trades) > DEFAULT_MAX_SEEN_TRADES:
            ordered = sorted(self.seen_trades.items(), key=lambda item: item[1], reverse=True)
            self.seen_trades = dict(ordered[:DEFAULT_MAX_SEEN_TRADES])
        if len(self.seen_reviews) > DEFAULT_MAX_SEEN_FILINGS:
            ordered = sorted(self.seen_reviews.items(), key=lambda item: item[1], reverse=True)
            self.seen_reviews = dict(ordered[:DEFAULT_MAX_SEEN_FILINGS])


@dataclass(frozen=True)
class TrackerConfig:
    branch: str
    legislative_source: str
    state_path: Path
    ledger_path: Path
    pending_path: Path
    result_path: Path
    latest_csv_path: Path
    oge_listings_path: Path | None
    bootstrap_alerts: bool
    no_notify: bool
    senate_lookback_days: int
    max_download_bytes: int
    max_ocr_pages: int
    user_agent: str
    pushover_api_token: str
    pushover_user_key: str
    require_pushover: bool
    notify_equity_only: bool
    notify_pending_reviews: bool
    watchlist: tuple[str, ...]
    allow_empty_sources: bool
    allow_state_initialization: bool
    terms_acknowledged: bool


@dataclass
class TrackerResult:
    branch: str
    started_utc: str
    finished_utc: str = ""
    source_counts: dict[str, int] = field(default_factory=dict)
    new_filing_counts: dict[str, int] = field(default_factory=dict)
    baseline_counts: dict[str, int] = field(default_factory=dict)
    purchase_counts: dict[str, int] = field(default_factory=dict)
    alerted_filing_counts: dict[str, int] = field(default_factory=dict)
    pending_review_counts: dict[str, int] = field(default_factory=dict)
    purchases: list[dict[str, Any]] = field(default_factory=list)
    pending_reviews: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    success: bool = False


def iso_utc(value: datetime | None = None) -> str:
    return (value or utc_now()).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def parse_watchlist(raw: str | None) -> tuple[str, ...]:
    if not raw:
        return ()
    values: list[str] = []
    seen: set[str] = set()
    for part in raw.split(","):
        value = normalize_text(part)
        if value and value.casefold() not in seen:
            values.append(value)
            seen.add(value.casefold())
    return tuple(values)


def normalize_date(value: str) -> str:
    value = normalize_text(value)
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%m-%d-%Y", "%m-%d-%y", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    return value


def normalize_amount(value: str) -> str:
    value = normalize_text(value).replace("—", "-").replace("–", "-")
    return re.sub(r"\s*-\s*", " - ", value)


def owner_label(value: str) -> str:
    normalized = normalize_text(value).upper()
    return OWNER_LABELS.get(normalized, normalize_text(value) or "Unknown")


def transaction_label(value: str) -> str:
    normalized = normalize_text(value).upper()
    return TRANSACTION_LABELS.get(normalized, normalize_text(value).title())


def extract_ticker(asset: str, explicit: str = "") -> str:
    explicit = normalize_text(explicit).upper()
    if explicit not in {"", "--", "N/A", "NONE"} and re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,7}", explicit):
        return explicit
    matches = TICKER_RE.findall(asset.upper())
    return matches[-1] if matches else ""


def infer_asset_type(asset: str, explicit: str = "") -> str:
    explicit = normalize_text(explicit)
    if explicit and explicit not in {"--", "None", "N/A"}:
        return explicit
    code_match = ASSET_CODE_RE.search(asset)
    if code_match:
        return code_match.group(1).upper()
    lowered = asset.casefold()
    if "stock option" in lowered or " call option" in lowered or " put option" in lowered:
        return "Stock Option"
    if "common stock" in lowered or "preferred stock" in lowered or re.search(r"\bstock\b", lowered):
        return "Stock"
    if "etf" in lowered or "exchange traded fund" in lowered or "exchange-traded fund" in lowered:
        return "ETF"
    if "bond" in lowered:
        return "Bond"
    return "Unknown"


def is_equity_like(asset: str, asset_type: str, ticker: str) -> bool:
    lowered_asset = asset.casefold()
    lowered_type = asset_type.casefold()
    code = asset_type.upper()
    if code in EQUITY_CODES:
        return True
    if any(term in lowered_type for term in EQUITY_TYPE_TERMS):
        return True
    if any(term in lowered_type for term in NON_EQUITY_TERMS):
        return False
    if any(term in lowered_asset for term in NON_EQUITY_TERMS):
        return False
    if any(term in lowered_asset for term in EQUITY_TYPE_TERMS):
        return True
    # A disclosed ticker with no bond/fund language is a useful medium-confidence
    # equity signal. The raw row remains available for review.
    return bool(ticker)


def clean_asset(asset: str) -> str:
    asset = normalize_text(asset)
    asset = re.sub(r"^(?:SP|JT|DC)\s+", "", asset, flags=re.IGNORECASE)
    return asset.strip(" |-")


def stable_id(prefix: str, values: Iterable[str]) -> str:
    material = "\x1f".join(normalize_text(value) for value in values)
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]
    return f"{prefix}:{digest}"


def make_trade(
    *,
    branch: str,
    source: str,
    report: Report | Mapping[str, Any],
    owner: str,
    asset: str,
    ticker: str,
    asset_type: str,
    transaction_type: str,
    transaction_date: str,
    notification_date: str,
    amount: str,
    raw_row: str,
    confidence: str,
) -> Trade:
    if isinstance(report, Report):
        report_id = report.report_id
        filer = report.filer
        filed_date = report.filed_date
        source_url = report.url
        chamber = report.source.title() if report.source in {"house", "senate"} else ""
        title = report.metadata.get("title", "")
        agency = report.metadata.get("agency", "")
    else:
        report_id = str(report.get("listing_id") or report.get("report_id") or "")
        filer = str(report.get("name") or report.get("filer") or "Unknown filer")
        filed_date = str(report.get("date") or report.get("filed_date") or "Unknown")
        source_url = str(
            report.get("document_url")
            or report.get("url")
            or report.get("request_url")
            or ""
        )
        chamber = str(report.get("chamber") or "")
        title = str(report.get("title") or "")
        agency = str(report.get("agency") or "")

    asset = clean_asset(asset)
    ticker = extract_ticker(asset, ticker)
    asset_type = infer_asset_type(asset, asset_type)
    transaction_type = transaction_label(transaction_type)
    transaction_date = normalize_date(transaction_date)
    notification_date = normalize_date(notification_date) if notification_date else ""
    amount = normalize_amount(amount)
    trade_id = stable_id(
        "trade",
        (
            source,
            report_id,
            filer,
            owner,
            asset,
            ticker,
            asset_type,
            transaction_type,
            transaction_date,
            amount,
        ),
    )
    return Trade(
        trade_id=trade_id,
        observed_at_utc=iso_utc(),
        branch=branch,
        source=source,
        report_id=report_id,
        filer=normalize_text(filer),
        chamber=normalize_text(chamber),
        title=normalize_text(title),
        agency=normalize_text(agency),
        owner=owner_label(owner),
        asset=asset,
        ticker=ticker,
        asset_type=asset_type,
        transaction_type=transaction_type,
        transaction_date=transaction_date,
        notification_date=notification_date,
        filed_date=normalize_date(filed_date),
        amount=amount,
        source_url=source_url,
        raw_row=normalize_text(raw_row),
        equity_like=is_equity_like(asset, asset_type, ticker),
        parse_confidence=confidence,
    )


def is_house_paper_text(text: str) -> bool:
    normalized = normalize_text(text).casefold()
    paper_markers = (
        "amount of transaction",
        "type of transaction",
        "hand delivered",
        "provide full name not ticker symbol",
    )
    electronic_markers = ("filing status:", "subholding of:")
    return any(marker in normalized for marker in paper_markers) and not any(
        marker in normalized for marker in electronic_markers
    )


def _house_transaction_region(text: str) -> list[str]:
    lines = [normalize_text(line) for line in text.splitlines() if normalize_text(line)]
    start = 0
    for index, line in enumerate(lines):
        if "$200?" in line or "Cap. Gains" in line:
            start = index + 1
            break
        if line.casefold() == "transactions":
            start = index + 1
    end = len(lines)
    for index in range(start, len(lines)):
        lowered = lines[index].casefold()
        if (
            "for the complete list of asset type abbreviations" in lowered
            or lowered.startswith("investment vehicle details")
            or lowered.startswith("initial public offerings")
            or lowered.startswith("certification and signature")
        ):
            end = index
            break
    return lines[start:end]


def parse_house_transactions(text: str, report: Report) -> list[Trade]:
    """Parse electronically generated House PTR text into normalized transactions."""
    if is_house_paper_text(text):
        raise PaperFilingError("House filing is a paper/scanned PTR; checkbox semantics require review")

    lines = _house_transaction_region(text)
    transactions: list[Trade] = []
    buffer: list[str] = []
    skip_prefixes = (
        "f s:",
        "s o:",
        "filing status:",
        "subholding of:",
        "filing id #",
        "id owner asset",
        "type date notification",
        "date amount",
    )

    index = 0
    while index < len(lines):
        line = lines[index]
        lowered = line.casefold()
        if lowered.startswith(skip_prefixes):
            index += 1
            continue
        # PDF text extraction sometimes wraps the upper half of an amount range onto
        # the next line. Join that continuation before matching the transaction.
        if re.search(r"\$[\d,]+\s*[-–—]\s*$", line) and index + 1 < len(lines):
            next_line = lines[index + 1]
            if re.fullmatch(r"\$?[\d,]+(?:\.\d{2})?", next_line):
                line = f"{line} {next_line}"
                index += 1

        buffer.append(line)
        combined = normalize_text(" ".join(buffer))
        match = HOUSE_TRANSACTION_RE.search(combined)
        if match:
            asset_prefix = combined[: match.start()].strip()
            owner_code = ""
            owner_match = re.match(r"^(SP|JT|DC)\s+", asset_prefix, re.IGNORECASE)
            if owner_match:
                owner_code = owner_match.group(1).upper()
                asset_prefix = asset_prefix[owner_match.end() :]
            asset_code_match = ASSET_CODE_RE.search(asset_prefix)
            asset_code = asset_code_match.group(1).upper() if asset_code_match else ""
            trade = make_trade(
                branch="legislative",
                source="house",
                report=report,
                owner=owner_code,
                asset=asset_prefix,
                ticker="",
                asset_type=asset_code,
                transaction_type=match.group("type"),
                transaction_date=match.group("date"),
                notification_date=match.group("notification"),
                amount=match.group("amount"),
                raw_row=combined,
                confidence="high",
            )
            transactions.append(trade)
            buffer = []
        elif len(combined) > 5_000:
            raise SourceChangedError(
                f"House PTR parser accumulated an implausibly long transaction row for {report.report_id}"
            )
        index += 1

    if not transactions:
        excerpt = normalize_text(text)[:500]
        raise SourceChangedError(
            f"Electronic House PTR {report.report_id} contains no parseable transactions: {excerpt!r}"
        )
    return transactions


def _canonical_header(value: str) -> str:
    value = normalize_text(value).casefold()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return value.strip()


def _header_index(headers: Sequence[str], *candidates: str) -> int | None:
    for candidate in candidates:
        candidate = _canonical_header(candidate)
        for index, header in enumerate(headers):
            if header == candidate:
                return index
    for candidate in candidates:
        candidate = _canonical_header(candidate)
        for index, header in enumerate(headers):
            if candidate in header:
                return index
    return None


def _cell(cells: Sequence[str], index: int | None) -> str:
    if index is None or index < 0 or index >= len(cells):
        return ""
    return cells[index]


def _infer_senate_cells(cells: Sequence[str]) -> dict[str, str]:
    date_index = next((i for i, value in enumerate(cells) if DATE_RE.fullmatch(value)), None)
    type_index = next(
        (
            i
            for i, value in enumerate(cells)
            if transaction_label(value).startswith(("Purchase", "Sale", "Exchange"))
            and normalize_text(value).upper() in TRANSACTION_LABELS
        ),
        None,
    )
    amount_index = next((i for i, value in enumerate(cells) if AMOUNT_RE.fullmatch(value)), None)
    if date_index is None or type_index is None or amount_index is None:
        return {}
    owner = cells[date_index + 1] if date_index + 1 < len(cells) else ""
    ticker = cells[date_index + 2] if date_index + 2 < len(cells) else ""
    asset_start = date_index + 3
    asset_end = type_index
    asset_type = ""
    if asset_end - asset_start >= 2:
        asset_type = cells[asset_end - 1]
        asset_end -= 1
    asset = " ".join(cells[asset_start:asset_end])
    return {
        "date": cells[date_index],
        "owner": owner,
        "ticker": ticker,
        "asset": asset,
        "asset_type": asset_type,
        "type": cells[type_index],
        "amount": cells[amount_index],
        "comment": " | ".join(cells[amount_index + 1 :]),
    }


def parse_senate_html_transactions(html: str, report: Report) -> list[Trade]:
    soup = BeautifulSoup(html, "html.parser")
    parsed: list[Trade] = []
    found_transaction_table = False

    for table in soup.find_all("table"):
        header_cells = table.find_all("th")
        headers = [_canonical_header(cell.get_text(" ", strip=True)) for cell in header_cells]
        date_index = _header_index(headers, "transaction date", "date")
        owner_index = _header_index(headers, "owner")
        ticker_index = _header_index(headers, "ticker")
        asset_index = _header_index(headers, "asset name", "asset")
        asset_type_index = _header_index(headers, "asset type")
        type_index = _header_index(headers, "transaction type", "type")
        amount_index = _header_index(headers, "amount")
        comment_index = _header_index(headers, "comment")

        if date_index is not None and type_index is not None and amount_index is not None:
            found_transaction_table = True

        for row in table.find_all("tr"):
            cells = [normalize_text(cell.get_text(" ", strip=True)) for cell in row.find_all("td")]
            if not cells:
                continue
            values: dict[str, str]
            if found_transaction_table and headers:
                values = {
                    "date": _cell(cells, date_index),
                    "owner": _cell(cells, owner_index),
                    "ticker": _cell(cells, ticker_index),
                    "asset": _cell(cells, asset_index),
                    "asset_type": _cell(cells, asset_type_index),
                    "type": _cell(cells, type_index),
                    "amount": _cell(cells, amount_index),
                    "comment": _cell(cells, comment_index),
                }
            else:
                values = _infer_senate_cells(cells)
            if not values:
                continue
            tx_type = transaction_label(values["type"])
            if tx_type not in {"Purchase", "Sale", "Sale (Full)", "Sale (Partial)", "Exchange"}:
                continue
            raw = " | ".join(cells)
            if values.get("comment"):
                raw = f"{raw} | {values['comment']}"
            parsed.append(
                make_trade(
                    branch="legislative",
                    source="senate",
                    report=report,
                    owner=values.get("owner", ""),
                    asset=values.get("asset", ""),
                    ticker=values.get("ticker", ""),
                    asset_type=values.get("asset_type", ""),
                    transaction_type=values["type"],
                    transaction_date=values["date"],
                    notification_date="",
                    amount=values["amount"],
                    raw_row=raw,
                    confidence="high",
                )
            )

    if not parsed:
        excerpt = normalize_text(soup.get_text(" ", strip=True))[:500]
        raise SourceChangedError(
            f"Senate electronic PTR {report.report_id} contains no parseable transaction rows: {excerpt!r}"
        )
    return parsed


def parse_generic_transactions_text(
    text: str,
    report: Report | Mapping[str, Any],
    *,
    branch: str,
    source: str,
    paper_is_pending: bool = True,
) -> list[Trade]:
    """Parse OGE-style or paper-report text where transaction type is written out."""
    lines = [normalize_text(line) for line in text.splitlines() if normalize_text(line)]
    parsed: list[Trade] = []
    buffer: list[str] = []
    header_terms = (
        "description type date",
        "transaction date owner",
        "periodic transaction report",
        "notification received over 30 days ago",
    )
    stop_terms = (
        "comments of reviewing officials",
        "certification and signature",
        "filer's certification",
        "reviewing official",
    )

    for line in lines:
        lowered = line.casefold()
        if any(term in lowered for term in header_terms):
            buffer = []
            continue
        if any(lowered.startswith(term) for term in stop_terms):
            buffer = []
            continue
        if re.search(r"\$[\d,]+\s*[-–—]\s*$", line):
            buffer.append(line)
            continue
        buffer.append(line)
        combined = normalize_text(" ".join(buffer))
        match = GENERIC_TRANSACTION_RE.search(combined)
        if not match:
            if len(combined) > 3_500:
                buffer = buffer[-8:]
            continue
        prefix = combined[: match.start()].strip(" |-")
        # Remove obvious row numbers and owner labels when present.
        prefix = re.sub(r"^\d+\s+", "", prefix)
        owner = ""
        owner_match = re.match(
            r"^(Self|Spouse|Joint|Dependent Child|SP|JT|DC)\s+",
            prefix,
            re.IGNORECASE,
        )
        if owner_match:
            owner = owner_match.group(1)
            prefix = prefix[owner_match.end() :]
        asset_type = infer_asset_type(prefix)
        parsed.append(
            make_trade(
                branch=branch,
                source=source,
                report=report,
                owner=owner,
                asset=prefix,
                ticker="",
                asset_type=asset_type,
                transaction_type=match.group("type"),
                transaction_date=match.group("date"),
                notification_date="",
                amount=match.group("amount"),
                raw_row=combined,
                confidence="medium",
            )
        )
        buffer = []

    if not parsed and paper_is_pending:
        raise PaperFilingError("Filing text does not preserve enough row structure for reliable parsing")
    if not parsed:
        raise SourceChangedError("Electronic filing contains no parseable transaction rows")
    return parsed


def purchases_only(transactions: Iterable[Trade]) -> list[Trade]:
    return [trade for trade in transactions if trade.transaction_type == "Purchase"]


def load_state(path: Path) -> tuple[TrackerState, bool]:
    if not path.exists():
        return TrackerState(), True
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MonitorError(f"Tracker state is unreadable: {path}: {exc}") from exc
    if not isinstance(payload, dict) or payload.get("version") != STATE_VERSION:
        raise MonitorError(
            f"Unsupported tracker state in {path}; expected version {STATE_VERSION}"
        )
    seen_payload = payload.get("seen_filings", {})
    seen_filings: dict[str, dict[str, str]] = {"house": {}, "senate": {}, "oge": {}}
    for source in seen_filings:
        source_payload = seen_payload.get(source, {})
        if not isinstance(source_payload, dict):
            raise MonitorError(f"State field seen_filings.{source} must be an object")
        seen_filings[source] = {str(k): str(v) for k, v in source_payload.items()}
    return (
        TrackerState(
            version=STATE_VERSION,
            seen_filings=seen_filings,
            seen_trades={str(k): str(v) for k, v in payload.get("seen_trades", {}).items()},
            seen_reviews={str(k): str(v) for k, v in payload.get("seen_reviews", {}).items()},
            last_attempt_utc=payload.get("last_attempt_utc"),
            last_success_utc=payload.get("last_success_utc"),
            last_counts={str(k): int(v) for k, v in payload.get("last_counts", {}).items()},
        ),
        False,
    )


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(text)
        temp_name = handle.name
    Path(temp_name).replace(path)


def save_state(path: Path, state: TrackerState) -> None:
    state.prune()
    payload = {
        "version": state.version,
        "seen_filings": state.seen_filings,
        "seen_trades": state.seen_trades,
        "seen_reviews": state.seen_reviews,
        "last_attempt_utc": state.last_attempt_utc,
        "last_success_utc": state.last_success_utc,
        "last_counts": state.last_counts,
    }
    atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")


def append_jsonl(path: Path, records: Iterable[Mapping[str, Any]]) -> None:
    rows = list(records)
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(dict(row), sort_keys=True) + "\n")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise MonitorError(f"Invalid JSONL in {path} at line {line_number}: {exc}") from exc
        if not isinstance(value, dict):
            raise MonitorError(f"JSONL record in {path} at line {line_number} is not an object")
        records.append(value)
    return records


def write_latest_csv(ledger_path: Path, output_path: Path, max_rows: int = DEFAULT_LATEST_CSV_ROWS) -> None:
    rows = read_jsonl(ledger_path)
    rows.sort(
        key=lambda row: (
            str(row.get("filed_date", "")),
            str(row.get("observed_at_utc", "")),
            str(row.get("trade_id", "")),
        ),
        reverse=True,
    )
    rows = rows[:max_rows]
    fieldnames = [field.name for field in Trade.__dataclass_fields__.values()]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        newline="",
        encoding="utf-8",
        dir=output_path.parent,
        prefix=f".{output_path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        temp_name = handle.name
    Path(temp_name).replace(output_path)


def write_result(path: Path, result: TrackerResult) -> None:
    atomic_write_text(path, json.dumps(asdict(result), indent=2, sort_keys=True) + "\n")


def _selected_legislative_sources(value: str) -> tuple[str, ...]:
    return ("house", "senate") if value == "all" else (value,)


def scan_house_report(session: Session, report: Report, config: TrackerConfig) -> tuple[list[Trade], PendingReview | None]:
    pdf_bytes = fetch_pdf_bytes(
        session,
        report.url,
        config,  # runtime duck typing: fetch_pdf_bytes uses max_download_bytes only
        f"House PTR {report.metadata.get('document_id', report.report_id)}",
    )
    try:
        text = extract_pdf_text(pdf_bytes, config.max_ocr_pages)
        return purchases_only(parse_house_transactions(text, report)), None
    except PaperFilingError as exc:
        review = make_pending_review(
            branch="legislative",
            source="house",
            report_id=report.report_id,
            filer=report.filer,
            filed_date=report.filed_date,
            source_url=report.url,
            reason=str(exc),
        )
        return [], review


def _senate_pdf_from_viewer(
    session: Session,
    response: Response,
    data: bytes,
    config: TrackerConfig,
) -> tuple[bytes, str]:
    content_type = response.headers.get("Content-Type", "").lower()
    if data.startswith(b"%PDF") or "application/pdf" in content_type:
        return data, response.url
    soup = BeautifulSoup(data, "html.parser")
    link = soup.find("a", href=re.compile(r"\.pdf(?:$|\?)", re.IGNORECASE))
    if not link or not link.get("href"):
        excerpt = normalize_text(soup.get_text(" ", strip=True))[:300]
        raise SourceChangedError(f"Senate paper PTR page contains no PDF link: {excerpt!r}")
    pdf_url = urljoin(response.url, str(link["href"]))
    pdf_response = checked_response(
        session.get(pdf_url, timeout=DEFAULT_TIMEOUT),
        f"Senate paper PTR PDF {pdf_url}",
    )
    return (
        response_bytes(pdf_response, f"Senate paper PTR PDF {pdf_url}", config.max_download_bytes),
        pdf_url,
    )


def scan_senate_report(session: Session, report: Report, config: TrackerConfig) -> tuple[list[Trade], PendingReview | None]:
    response = _senate_page_response(session, report)
    data = response_bytes(response, f"Senate PTR {report.url}", config.max_download_bytes)
    content_type = response.headers.get("Content-Type", "").lower()

    if report.format == "pdf" or data.startswith(b"%PDF") or "application/pdf" in content_type:
        pdf_bytes, _pdf_url = _senate_pdf_from_viewer(session, response, data, config)
        try:
            text = extract_pdf_text(pdf_bytes, config.max_ocr_pages)
            transactions = parse_generic_transactions_text(
                text,
                report,
                branch="legislative",
                source="senate",
                paper_is_pending=True,
            )
            return purchases_only(transactions), None
        except PaperFilingError as exc:
            return [], make_pending_review(
                branch="legislative",
                source="senate",
                report_id=report.report_id,
                filer=report.filer,
                filed_date=report.filed_date,
                source_url=report.url,
                reason=str(exc),
            )

    html = data.decode(response.encoding or "utf-8", errors="replace")
    return purchases_only(parse_senate_html_transactions(html, report)), None


def make_pending_review(
    *,
    branch: str,
    source: str,
    report_id: str,
    filer: str,
    filed_date: str,
    source_url: str,
    reason: str,
    title: str = "",
    agency: str = "",
) -> PendingReview:
    review_id = stable_id("review", (source, report_id, filer, source_url, reason))
    return PendingReview(
        review_id=review_id,
        observed_at_utc=iso_utc(),
        branch=branch,
        source=source,
        report_id=report_id,
        filer=normalize_text(filer),
        filed_date=normalize_date(filed_date),
        source_url=source_url,
        reason=normalize_text(reason),
        title=normalize_text(title),
        agency=normalize_text(agency),
    )


def load_oge_listings(path: Path) -> list[dict[str, Any]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MonitorError(f"OGE listing file is unreadable: {path}: {exc}") from exc
    listings = payload.get("listings") if isinstance(payload, dict) else payload
    if not isinstance(listings, list):
        raise MonitorError(f"OGE listing file does not contain a listings array: {path}")
    normalized: list[dict[str, Any]] = []
    for item in listings:
        if not isinstance(item, dict):
            raise MonitorError(f"OGE listing is not an object: {item!r}")
        listing_id = str(item.get("listing_id") or "")
        if not listing_id:
            raise MonitorError(f"OGE listing is missing listing_id: {item!r}")
        normalized.append(dict(item))
    deduped = {str(item["listing_id"]): item for item in normalized}
    return sorted(deduped.values(), key=lambda item: (str(item.get("date", "")), str(item["listing_id"])))


def resolve_oge_pdf(session: Session, listing: Mapping[str, Any], config: TrackerConfig) -> bytes | None:
    access_mode = normalize_text(str(listing.get("access_mode", "unknown"))).casefold()
    if access_mode == "request":
        return None
    url = str(listing.get("document_url") or listing.get("url") or "").strip()
    if not url:
        return None
    response = checked_response(session.get(url, timeout=DEFAULT_TIMEOUT), f"OGE disclosure {url}")
    data = response_bytes(response, f"OGE disclosure {url}", config.max_download_bytes)
    content_type = response.headers.get("Content-Type", "").lower()
    if data.startswith(b"%PDF") or "application/pdf" in content_type:
        return data
    soup = BeautifulSoup(data, "html.parser")
    pdf_links = [
        urljoin(response.url, str(link["href"]))
        for link in soup.find_all("a", href=True)
        if re.search(r"\.pdf(?:$|\?)", str(link["href"]), re.IGNORECASE)
    ]
    if pdf_links:
        pdf_response = checked_response(
            session.get(pdf_links[0], timeout=DEFAULT_TIMEOUT),
            f"OGE disclosure PDF {pdf_links[0]}",
        )
        return response_bytes(
            pdf_response,
            f"OGE disclosure PDF {pdf_links[0]}",
            config.max_download_bytes,
        )
    page_text = normalize_text(soup.get_text(" ", strip=True)).casefold()
    if "form 201" in page_text or "request" in page_text:
        return None
    raise SourceChangedError(f"OGE disclosure landing page has no PDF or request path: {url}")


def scan_oge_listing(
    session: Session,
    listing: Mapping[str, Any],
    config: TrackerConfig,
) -> tuple[list[Trade], PendingReview | None]:
    pdf_bytes = resolve_oge_pdf(session, listing, config)
    listing_id = str(listing["listing_id"])
    filer = str(listing.get("name") or "Unknown filer")
    filed_date = str(listing.get("date") or "Unknown")
    source_url = str(
        listing.get("document_url")
        or listing.get("request_url")
        or listing.get("url")
        or ""
    )
    if pdf_bytes is None:
        return [], make_pending_review(
            branch="executive",
            source="oge",
            report_id=listing_id,
            filer=filer,
            filed_date=filed_date,
            source_url=source_url,
            reason="OGE Form 278-T is listed, but access requires an OGE Form 201 request or no direct PDF was published",
            title=str(listing.get("title") or ""),
            agency=str(listing.get("agency") or ""),
        )
    try:
        text = extract_pdf_text(pdf_bytes, config.max_ocr_pages)
        transactions = parse_generic_transactions_text(
            text,
            listing,
            branch="executive",
            source="oge",
            paper_is_pending=True,
        )
        return purchases_only(transactions), None
    except PaperFilingError as exc:
        return [], make_pending_review(
            branch="executive",
            source="oge",
            report_id=listing_id,
            filer=filer,
            filed_date=filed_date,
            source_url=source_url,
            reason=str(exc),
            title=str(listing.get("title") or ""),
            agency=str(listing.get("agency") or ""),
        )


def trade_matches_watchlist(trade: Trade, watchlist: Sequence[str]) -> bool:
    if not watchlist:
        return True
    haystack = f"{trade.ticker} {trade.asset}".casefold()
    return any(item.casefold() in haystack for item in watchlist)


def selected_for_notification(trades: Sequence[Trade], config: TrackerConfig) -> list[Trade]:
    selected = [trade for trade in trades if trade_matches_watchlist(trade, config.watchlist)]
    if config.notify_equity_only:
        selected = [trade for trade in selected if trade.equity_like]
    return selected


def _truncate(value: str, limit: int) -> str:
    value = normalize_text(value)
    return value if len(value) <= limit else value[: limit - 1] + "…"


def _pushover_post(
    session: Session,
    config: TrackerConfig,
    *,
    title: str,
    message: str,
    url: str,
    url_title: str,
) -> None:
    if config.no_notify:
        LOGGER.warning("Notification suppressed (--no-notify): %s — %s", title, message)
        return
    if not config.pushover_api_token or not config.pushover_user_key:
        if config.require_pushover:
            raise NotificationError("Pushover credentials are required but missing")
        LOGGER.warning("Pushover credentials are absent; notification logged only: %s", title)
        return
    response = session.post(
        PUSHOVER_MESSAGES_URL,
        data={
            "token": config.pushover_api_token,
            "user": config.pushover_user_key,
            "title": _truncate(title, 250),
            "message": _truncate(message, 1024),
            "url": url,
            "url_title": _truncate(url_title, 100),
            "priority": "0",
        },
        timeout=DEFAULT_TIMEOUT,
    )
    try:
        response.raise_for_status()
    except requests.HTTPError as exc:
        excerpt = normalize_text(response.text)[:300]
        raise NotificationError(
            f"Pushover returned HTTP {response.status_code}: {excerpt!r}"
        ) from exc
    try:
        body = response.json()
    except requests.JSONDecodeError as exc:
        raise NotificationError("Pushover returned non-JSON content") from exc
    if body.get("status") != 1:
        raise NotificationError(f"Pushover rejected notification: {body!r}")


def send_purchase_notification(
    session: Session,
    config: TrackerConfig,
    filing_label: str,
    trades: Sequence[Trade],
) -> bool:
    selected = selected_for_notification(trades, config)
    if not selected:
        return False
    filer = selected[0].filer
    source = selected[0].source.title()
    lines = [f"{filer} • {source} • {len(selected)} disclosed purchase(s)"]
    for trade in selected[:7]:
        asset_label = trade.ticker or _truncate(trade.asset, 32)
        owner = f" • {trade.owner}" if trade.owner and trade.owner != "Self" else ""
        lines.append(
            f"{asset_label} • {trade.amount} • {trade.transaction_date}{owner}"
        )
    if len(selected) > 7:
        lines.append(f"+{len(selected) - 7} more purchase(s)")
    _pushover_post(
        session,
        config,
        title=f"Government purchase disclosure: {filer}",
        message="\n".join(lines),
        url=selected[0].source_url,
        url_title=f"Open {filing_label}",
    )
    return True


def send_pending_notification(
    session: Session,
    config: TrackerConfig,
    review: PendingReview,
) -> bool:
    if not config.notify_pending_reviews:
        return False
    message = f"{review.filer} • {review.source.title()}\n{review.reason}"
    _pushover_post(
        session,
        config,
        title=f"Government filing needs review: {review.filer}",
        message=message,
        url=review.source_url,
        url_title="Open filing or request page",
    )
    return True


def commit_filing_outcome(
    *,
    session: Session,
    config: TrackerConfig,
    state: TrackerState,
    result: TrackerResult,
    source: str,
    filing_id: str,
    filing_label: str,
    trades: Sequence[Trade],
    review: PendingReview | None,
) -> None:
    fresh_trades = [trade for trade in trades if trade.trade_id not in state.seen_trades]
    alerted = False
    if fresh_trades:
        alerted = send_purchase_notification(session, config, filing_label, fresh_trades)
    if review and review.review_id not in state.seen_reviews:
        alerted = send_pending_notification(session, config, review) or alerted

    timestamp = iso_utc()
    if fresh_trades:
        append_jsonl(config.ledger_path, (asdict(trade) for trade in fresh_trades))
        for trade in fresh_trades:
            state.seen_trades[trade.trade_id] = timestamp
            result.purchases.append(asdict(trade))
        result.purchase_counts[source] = result.purchase_counts.get(source, 0) + len(fresh_trades)
    if review and review.review_id not in state.seen_reviews:
        append_jsonl(config.pending_path, (asdict(review),))
        state.seen_reviews[review.review_id] = timestamp
        result.pending_reviews.append(asdict(review))
        result.pending_review_counts[source] = result.pending_review_counts.get(source, 0) + 1
    if alerted:
        result.alerted_filing_counts[source] = result.alerted_filing_counts.get(source, 0) + 1
    state.mark_filing_seen(source, filing_id, timestamp)
    save_state(config.state_path, state)


def _baseline_source(
    state: TrackerState,
    source: str,
    filing_ids: Iterable[str],
    result: TrackerResult,
) -> None:
    timestamp = iso_utc()
    ids = list(filing_ids)
    for filing_id in ids:
        state.mark_filing_seen(source, filing_id, timestamp)
    result.baseline_counts[source] = len(ids)


def should_baseline_source(
    state: TrackerState,
    source: str,
    config: TrackerConfig,
) -> bool:
    """Return whether a silent baseline is authorized for a source with no state.

    An existing but incomplete state file must not silently authorize a new source on a
    later scheduled run. Initialization must be explicit on the run that establishes the
    source baseline. ``bootstrap_alerts`` is also explicit, but processes rather than
    baselines every visible filing.
    """
    if state.seen_filings.get(source):
        return False
    if config.bootstrap_alerts:
        return False
    if not config.allow_state_initialization:
        raise MonitorError(
            f"{source.title()} has no durable baseline and "
            "ALLOW_STATE_INITIALIZATION is false. Run the workflow manually with "
            "initialize_state=true, or restore a complete state artifact."
        )
    return True


def run_legislative(
    config: TrackerConfig,
    state: TrackerState,
    result: TrackerResult,
    session: Session,
) -> None:
    current_year = utc_now().year
    for source in _selected_legislative_sources(config.legislative_source):
        if source == "house":
            reports = fetch_house_reports(
                session,
                years=(current_year - 1, current_year),
                max_download_bytes=config.max_download_bytes,
            )
            scanner = scan_house_report
        else:
            reports = fetch_senate_reports(
                session,
                lookback_days=config.senate_lookback_days,
            )
            scanner = scan_senate_report

        result.source_counts[source] = len(reports)
        result.purchase_counts[source] = 0
        result.pending_review_counts[source] = 0
        result.alerted_filing_counts[source] = 0
        if not reports and not config.allow_empty_sources:
            raise SourceChangedError(f"{source.title()} returned zero PTRs")

        source_bootstrap = should_baseline_source(state, source, config)
        unseen = [report for report in reports if not state.is_filing_seen(source, report.report_id)]
        result.new_filing_counts[source] = len(unseen)
        result.baseline_counts[source] = 0

        if source_bootstrap and not config.bootstrap_alerts:
            _baseline_source(state, source, (report.report_id for report in reports), result)
            state.last_counts[source] = len(reports)
            save_state(config.state_path, state)
            LOGGER.info("Baselined %s existing %s PTRs", len(reports), source)
            continue

        for report in unseen:
            LOGGER.info("Scanning new %s PTR for %s: %s", source, report.filer, report.url)
            trades, review = scanner(session, report, config)
            commit_filing_outcome(
                session=session,
                config=config,
                state=state,
                result=result,
                source=source,
                filing_id=report.report_id,
                filing_label=f"{source.title()} PTR",
                trades=trades,
                review=review,
            )
        state.last_counts[source] = len(reports)


def run_executive(
    config: TrackerConfig,
    state: TrackerState,
    result: TrackerResult,
    session: Session,
) -> None:
    if config.oge_listings_path is None:
        raise ValueError("--oge-listings-file is required for the executive branch")
    listings = load_oge_listings(config.oge_listings_path)
    source = "oge"
    result.source_counts[source] = len(listings)
    result.purchase_counts[source] = 0
    result.pending_review_counts[source] = 0
    result.alerted_filing_counts[source] = 0
    if not listings and not config.allow_empty_sources:
        raise SourceChangedError("OGE discovery returned zero Form 278-T listings")

    source_bootstrap = should_baseline_source(state, source, config)
    unseen = [item for item in listings if not state.is_filing_seen(source, str(item["listing_id"]))]
    result.new_filing_counts[source] = len(unseen)
    result.baseline_counts[source] = 0

    if source_bootstrap and not config.bootstrap_alerts:
        _baseline_source(state, source, (str(item["listing_id"]) for item in listings), result)
        state.last_counts[source] = len(listings)
        save_state(config.state_path, state)
        LOGGER.info("Baselined %s existing OGE 278-T listings", len(listings))
        return

    for listing in unseen:
        listing_id = str(listing["listing_id"])
        LOGGER.info("Scanning new OGE listing for %s", listing.get("name", "Unknown filer"))
        trades, review = scan_oge_listing(session, listing, config)
        commit_filing_outcome(
            session=session,
            config=config,
            state=state,
            result=result,
            source=source,
            filing_id=listing_id,
            filing_label="OGE Form 278-T",
            trades=trades,
            review=review,
        )
    state.last_counts[source] = len(listings)


def _write_step_summary(result: TrackerResult) -> None:
    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if not summary_path:
        return
    lines = [
        "## Government purchase tracker",
        "",
        f"- Branch: {result.branch}",
        f"- Success: {str(result.success).lower()}",
        f"- Started: {result.started_utc}",
        f"- Finished: {result.finished_utc}",
    ]
    for source in sorted(result.source_counts):
        lines.append(
            f"- {source.title()}: {result.source_counts[source]} visible, "
            f"{result.new_filing_counts.get(source, 0)} new filings, "
            f"{result.purchase_counts.get(source, 0)} purchases, "
            f"{result.pending_review_counts.get(source, 0)} review items, "
            f"{result.baseline_counts.get(source, 0)} baselined"
        )
    if result.errors:
        lines.extend(["", "### Errors", *[f"- {error}" for error in result.errors]])
    Path(summary_path).open("a", encoding="utf-8").write("\n".join(lines) + "\n")


def run_tracker(config: TrackerConfig, session: Session | None = None) -> TrackerResult:
    started = iso_utc()
    result = TrackerResult(branch=config.branch, started_utc=started)
    session = session or build_session(config.user_agent)
    try:
        if not config.terms_acknowledged:
            raise MonitorError(
                "DISCLOSURE_TERMS_ACKNOWLEDGED is false. Review the statutory use restrictions, "
                "then explicitly acknowledge them before accessing disclosure reports."
            )
        if (
            config.require_pushover
            and not config.no_notify
            and (not config.pushover_api_token or not config.pushover_user_key)
        ):
            raise NotificationError(
                "REQUIRE_PUSHOVER is enabled, but PUSHOVER_API_TOKEN/PUSHOVER_USER_KEY are missing"
            )
        if not config.state_path.exists() and not config.allow_state_initialization:
            raise MonitorError(
                "Tracker state is missing and ALLOW_STATE_INITIALIZATION is false. "
                "Restore the state artifact or explicitly initialize a new baseline."
            )

        state, _brand_new_state = load_state(config.state_path)
        state.last_attempt_utc = started
        save_state(config.state_path, state)
        if config.branch == "legislative":
            run_legislative(config, state, result, session)
        else:
            run_executive(config, state, result, session)
        state.last_success_utc = iso_utc()
        save_state(config.state_path, state)
        write_latest_csv(config.ledger_path, config.latest_csv_path)
        result.success = True
        return result
    except Exception as exc:
        result.errors.append(f"{type(exc).__name__}: {exc}")
        raise
    finally:
        result.finished_utc = iso_utc()
        write_result(config.result_path, result)
        _write_step_summary(result)


def build_config(args: argparse.Namespace) -> TrackerConfig:
    env = os.environ
    branch = args.branch
    if branch == "legislative":
        default_state = DEFAULT_LEGISLATIVE_STATE
        default_ledger = DEFAULT_LEGISLATIVE_LEDGER
        default_pending = DEFAULT_LEGISLATIVE_PENDING
        default_result = DEFAULT_LEGISLATIVE_RESULT
        default_csv = DEFAULT_LEGISLATIVE_CSV
    else:
        default_state = DEFAULT_EXECUTIVE_STATE
        default_ledger = DEFAULT_EXECUTIVE_LEDGER
        default_pending = DEFAULT_EXECUTIVE_PENDING
        default_result = DEFAULT_EXECUTIVE_RESULT
        default_csv = DEFAULT_EXECUTIVE_CSV

    user_agent = env.get(
        "DISCLOSURE_USER_AGENT",
        "Mozilla/5.0 (compatible; MyETFGovernmentTradeTracker/1.0; +https://github.com/maglothinm/MyETF)",
    ).strip()
    if not user_agent:
        raise ValueError("DISCLOSURE_USER_AGENT must not be empty")
    return TrackerConfig(
        branch=branch,
        legislative_source=args.source,
        state_path=Path(args.state_file or env.get("STATE_FILE", default_state)),
        ledger_path=Path(args.ledger_file or env.get("LEDGER_FILE", default_ledger)),
        pending_path=Path(args.pending_file or env.get("PENDING_FILE", default_pending)),
        result_path=Path(args.result_file or env.get("RESULT_FILE", default_result)),
        latest_csv_path=Path(args.latest_csv or env.get("LATEST_CSV", default_csv)),
        oge_listings_path=(
            Path(args.oge_listings_file or env["OGE_LISTINGS_FILE"])
            if (args.oge_listings_file or env.get("OGE_LISTINGS_FILE"))
            else None
        ),
        bootstrap_alerts=(
            args.bootstrap_alerts or parse_bool(env.get("BOOTSTRAP_ALERTS"), default=False)
        ),
        no_notify=args.no_notify,
        senate_lookback_days=int(
            args.senate_lookback_days
            or env.get("SENATE_LOOKBACK_DAYS", DEFAULT_SENATE_LOOKBACK_DAYS)
        ),
        max_download_bytes=int(env.get("MAX_DOWNLOAD_BYTES", DEFAULT_MAX_DOWNLOAD_BYTES)),
        max_ocr_pages=int(env.get("OCR_MAX_PAGES", DEFAULT_MAX_OCR_PAGES)),
        user_agent=user_agent,
        pushover_api_token=env.get("PUSHOVER_API_TOKEN", "").strip(),
        pushover_user_key=env.get("PUSHOVER_USER_KEY", "").strip(),
        require_pushover=parse_bool(env.get("REQUIRE_PUSHOVER"), default=False),
        notify_equity_only=parse_bool(env.get("NOTIFY_EQUITY_ONLY"), default=True),
        notify_pending_reviews=parse_bool(env.get("NOTIFY_PENDING_REVIEWS"), default=True),
        watchlist=parse_watchlist(args.watchlist or env.get("WATCHLIST")),
        allow_empty_sources=parse_bool(env.get("ALLOW_EMPTY_SOURCES"), default=False),
        allow_state_initialization=parse_bool(
            env.get("ALLOW_STATE_INITIALIZATION"), default=False
        ),
        terms_acknowledged=(
            args.acknowledge_terms
            or parse_bool(env.get("DISCLOSURE_TERMS_ACKNOWLEDGED"), default=False)
        ),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--branch", choices=("legislative", "executive"), required=True)
    parser.add_argument(
        "--source",
        choices=("all", "house", "senate"),
        default="all",
        help="Legislative source to query (default: all)",
    )
    parser.add_argument("--oge-listings-file", help="JSON produced by oge_disclosures.py")
    parser.add_argument("--state-file")
    parser.add_argument("--ledger-file")
    parser.add_argument("--pending-file")
    parser.add_argument("--result-file")
    parser.add_argument("--latest-csv")
    parser.add_argument("--watchlist", help="Optional comma-separated ticker/company alert filter")
    parser.add_argument("--senate-lookback-days", type=int)
    parser.add_argument("--bootstrap-alerts", action="store_true")
    parser.add_argument("--no-notify", action="store_true")
    parser.add_argument("--acknowledge-terms", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    try:
        config = build_config(args)
        result = run_tracker(config)
    except (MonitorError, ValueError, requests.RequestException) as exc:
        LOGGER.error("Government purchase tracking failed: %s", exc)
        return 1
    except Exception:
        LOGGER.exception("Unexpected government purchase tracking failure")
        return 1
    LOGGER.info(
        "Tracking succeeded: visible=%s new=%s purchases=%s pending=%s",
        result.source_counts,
        result.new_filing_counts,
        result.purchase_counts,
        result.pending_review_counts,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
