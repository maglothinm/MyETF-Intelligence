"""MyETF automation scripts."""
